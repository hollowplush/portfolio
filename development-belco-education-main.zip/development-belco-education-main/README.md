## Name
Belco Education website prototype.

## Description
This project is part of our school assignment. We're working with our client, Belco Education, to redesign and develop a modern website for students interested in study programs abroad.

The exisiting Belco website is outdated, and we're creating a fresh, user-friendly design based on it.
- You can view the old site here: https://belco-edu.com/ 

## Visuals
Below are a few design mockups we're aiming to recreate in our development project:

- ![Design of home page with map.](image.png)
- ![Design of 'list of schools' page](image-1.png)
- ![Design of contact page](image-2.png)
- ![Design Info page about schools](image-3.png)

## Installation
Whether you're a beginner or more advanced, here are multiple ways to run this project:

Option 1: Download ZIP
1. Click the green "Code" button on this repo > "Download Zip"
2. Extract the folder
3. Double-click index.html to open in your browser

Option 2: With VS Code + Live Server
1. Open the folder in VS Code
2. Install Live Server extension (if not already installed)
3. Right-click on index.html > "Open with Live Server"

Your browser wil open and show the website.

If you have any trouble or questions in general regarding the installation of this project, feel free to contact us!

## License
(License info will be added later)

Currently, this is a school project and not for commercial use. Feel free to explore, but please don't reuse the material without asking us first.

## Project status
We are in the early development phase. This is a learning project -- both team members are beginners in HTML, CSS and JavaScript. We're using examples and tutorials to improve as we go.

Feedback, advice or constructive criticism is very welcome!

Completed tasks:
- Review Figma prototype
- Set up Git/GitHub repo
- Basic folder structure
- IDE and installation tools deciced

In progress:
- Match layout to Figma
- Start applying CSS styles
- Make layout responsive

Coming soon (to do list):
- Add simple JS interactions (e.g., button clicks)
- Fix layout/UI 
- Test in different sceen sizes
- Adjust README accordingly when project is finalised


## Project Members
This project is developed by:
- Malou Bruil, ICT: Media & Design student at Fontys (Eindhoven) (m.bruil@student.fontys.nl)
- Charlotte Mies, ICT: Media & Design student at Fontys (Eindhoven) (c.mies@student.fontys.nl)
